package net.vingroup.ecar.Util;

/**
 * Created by redsu on 12/20/2017.
 */

public class Constant {

//    public static String PUBLICSTATIC = "PFJTQUtleVZhbHVlPjxNb2R1bHVzPnJhVitzM2hYOUZ6WFZSc0J5bzV4MXpLdVVNRDRBRHVJNkFYQzNnUmQvZkdPL2QxYTh2ZUdXQlRCNXZhQzM3QnZValdHVVFhbytpaTV6NlhZaGViSHZTRkdZbW1qWkVqbmkrcXB5NFRBODFRNFV4WitDV3llV2hKc3p4ODZPcmNCNzNHdVVydEJmR1lGZUI1QlBVbEsyb1dGQWxJVDdUSDZZRXlxMjIyZmFDTT08L01vZHVsdXM+PEV4cG9uZW50PkFRQUI8L0V4cG9uZW50PjwvUlNBS2V5VmFsdWU+";
//    public static String USERNAME = "knox_moblie";
//    public static String PASSWORD = "sb7maKUv";
    public static String CLIENTID = "73768738-ed83-4dee-a0b5-8c66da5c6937";
    public static String KEY_FIREBASE_CODE = "firebase_key";

    public static String APIURL = "https://simapi.vingroup.net/vincommerce";

    public static String APILOGIN   = "/ApiServiceCenter/CheckLogin";
    public static String APIGETTICKET = "/ApiServiceCenter/GetCarService";
    public static String APIGETDRIVER = "/ApiServiceCenter/GetTechnicianList";
    public static String APIUPDATETICKET = "/ApiServiceCenter/ChangeStatusTicket";
    public static String APIASSIGNDRIVER = "/ApiServiceCenter/AssignmentTechnician";
    public static String APIGETLISTSTATUSTICKET = "/ApiServiceCenter/ListStatus";

    public static String APIINSERTDEVICE = "/ApiServiceCenter/DeviceIDInsert";

}
